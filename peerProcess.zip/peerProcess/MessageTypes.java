/**
 *
 *   Enum to store message types
 *
 */

public enum MessageTypes {
    choke,
    unchoke,
    interested,
    notInterested,
    have,
    bitfield,
    request,
    piece;
}
